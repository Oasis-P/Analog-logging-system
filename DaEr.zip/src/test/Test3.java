package test;


import java.awt.Font;
import java.io.IOException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Test3 //��ͼ 
{
	public JFreeChart chart0(double[] value) throws IOException
	{
            XYSeriesCollection mCollection = new XYSeriesCollection();
            XYSeries mSeriesFirst = new XYSeries("First");
            for(int i=5;i<1030;i++)
            	mSeriesFirst.add(i-6, value[i]);
            
            StandardChartTheme mChartTheme = new StandardChartTheme("CN");
            mChartTheme.setLargeFont(new Font("����", Font.BOLD, 20));
            mChartTheme.setExtraLargeFont(new Font("����", Font.PLAIN, 15));
            mChartTheme.setRegularFont(new Font("����", Font.PLAIN, 15));
            
            mCollection.addSeries(mSeriesFirst);//�������ʽ����ChartFactory
           // ChartFactory.setChartTheme(mChartTheme);//���ݷ���mCollection
            XYSeriesCollection myCollection = mCollection;//ChartFactory����mChart
            JFreeChart mChart = ChartFactory.createXYLineChart("����ͼ", "X","Y", myCollection, PlotOrientation.VERTICAL,
                    true,true,false);
            return mChart;
    }
}