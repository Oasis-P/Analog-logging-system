package test;
import java.awt.Color;
import java.awt.Font;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.HorizontalAlignment;
import org.jfree.ui.RectangleEdge;

public class Test2 {

	XYSeriesCollection dataset1;
	XYSeriesCollection dataset2;
	XYSeriesCollection dataset3;
	JFreeChart chart;
	XYPlot plot;
	
	public Test2() {
		// ��������
		XYSeries series1 = new XYSeries("ϵ��1");
		series1.add(1, 2);
		series1.add(2, 4);
		series1.add(7, 6);

		XYSeries series2 = new XYSeries("ϵ��2");
		series2.add(5, 2);
		series2.add(3, 4);
		series2.add(7, 3);

		XYSeries series3 = new XYSeries("ϵ��3");
		series3.add(3, 2);
		series3.add(5, 4);
		series3.add(4, 6);

		dataset1 = new XYSeriesCollection();
		dataset2 = new XYSeriesCollection();
		dataset3 = new XYSeriesCollection();
		
		dataset1.addSeries(series1);
		dataset2.addSeries(series2);
		dataset3.addSeries(series3);

		chart = ChartFactory.createXYLineChart("MultiAxis", "X axis",
				"First Y Axis", dataset1, PlotOrientation.VERTICAL, true, true,
				false);

		plot = chart.getXYPlot();

		
		// ���ӵ�2��Y��
		
		NumberAxis axis2 = new NumberAxis("Second Axis");
			// -- �޸ĵ�2��Y�����ʾЧ��
		axis2.setAxisLinePaint(Color.BLUE);
		axis2.setLabelPaint(Color.BLUE);
		axis2.setTickLabelPaint(Color.BLUE);
		
		plot.setRangeAxis(1, axis2);
		plot.setDataset(1, dataset2);
		plot.mapDatasetToRangeAxis(1, 1);
		     // -- �޸ĵ�2��������ʾЧ��
		XYLineAndShapeRenderer render2 =  new XYLineAndShapeRenderer();	
		render2.setSeriesPaint(0, Color.BLUE);
		plot.setRenderer(1, render2);
		
		
		// ���ӵ�3��Y��
		NumberAxis axis3 = new NumberAxis("Third Axis");
		
		axis3.setAxisLinePaint(Color.GREEN);
		axis3.setLabelPaint(Color.GREEN);
		axis3.setTickLabelPaint(Color.GREEN);
		
		plot.setRangeAxis(2, axis3);
		plot.setDataset(2, dataset3);
		plot.mapDatasetToRangeAxis(2, 2);
		
		XYLineAndShapeRenderer render3 =  new XYLineAndShapeRenderer();	
		render3.setSeriesPaint(0, Color.GREEN);
		plot.setRenderer(2, render3);
		
		
		/*TextTitle copyright = new TextTitle(" С������@Java Eye    ");
		copyright.setPosition(RectangleEdge.BOTTOM);
		copyright.setHorizontalAlignment(HorizontalAlignment.RIGHT);
		copyright.setFont(new Font("����", 12, 12));
		chart.addSubtitle(copyright);*/
		chart.getLegend().setItemFont(new Font("����", 12, 12));
	}

	public static void main(String[] agrs) {
		Test2 obj = new Test2();
		ChartFrame frame = new ChartFrame("��������", obj.chart);
		frame.pack();
		frame.setVisible(true);
	}

}
