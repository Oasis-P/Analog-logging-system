package test;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import Interface.Interface;

public class read_t 
{	
	static double[] data=new double[1030];
		/*��ȡ�ļ����µ��ı��ļ�*/
		public static ArrayList<File> getFiles(String path) throws Exception 
		{
			ArrayList<File> fileList = new ArrayList<File>();
			File file = new File(path);
			if(file.isDirectory())
			{
				File []files = file.listFiles();
				for(File fileIndex:files)
				{
					if(fileIndex.isDirectory())
					{
						getFiles(fileIndex.getPath());
					}
					else 
					{
						fileList.add(fileIndex);
					}
				}
			}
			return fileList;
		}
		/* ��ȡ�ļ��е����� */
		public static double[] readTxt(String filePath1) throws IOException
		{// TODO �Զ����ɵķ������ 
				double[] value=new double[1030];
	            FileReader  fr=new FileReader(filePath1);
	            BufferedReader bfr=new BufferedReader(fr);
	            String[] s=new String[1030];
	            int i=0;
	            String str;
	            String[] st;
	            while((str=bfr.readLine())!=null) 
	            {
	                st=str.split(",");
	                for(String j:st)
	                {
	                    s[i]=j;
	                    i++;
	                }
	            }
	            bfr.close();
	            fr.close();
	            for(i=0;i<1030;i++) 
	            {
	            	value[i] = Double.valueOf(s[i].toString());
	            }
	            return value;
	    }
		/*public static void mm(JFrame frame) throws Exception
		{
			ChartPanel 
			pan=new ChartPanel(null);  
			Test3 test=new Test3();
			ArrayList<File> fileList = getFiles("D:\\0218\\���\\1");
			String curpath = fileList.get(0).getPath();//��ȡ�ļ�·��
		    depth=readTxt(curpath);
		    pan.setChart(test.chart0(depth));
		    System.out.println(fileList);
		    pan.setBounds(0, 0, 600, 450);
		    frame.add(pan);
			for(int i=0;i<fileList.size();i++)
			{
			    curpath = fileList.get(i).getPath();//��ȡ�ļ�·��
			    depth=readTxt(curpath);
			    pan.setChart(test.chart0(depth));
			    Thread.sleep(1000);
			    System.out.println(curpath);
			    pan.setBounds(0, 0, 600, 450);
			    frame.add(pan);
			   // Thread.sleep(1000);
			}	
		}*/
				 
		public static  ChartPanel mai(Interface inter) throws Exception 
		{
			ChartPanel pan=new ChartPanel(null);
			
			//frame.setSize(600, 450);
			//frame.setLocationRelativeTo(null);//����λ��
			//frame.setVisible(true);
			//frame.setDefaultCloseOperation(3);
			Test3 test=new Test3();
			//frame=Interface.view();
			/*JTextField text =new JTextField();
			JButton button1 = new JButton("��ʼģ��");
			text.setBounds(20, 460, 400, 40);
			button1.setBounds(30, 510, 200, 40);
			frame.add(text);
		    frame.add(button1);*/
		    
		    /*button1.addActionListener(new ActionListener()
		    		{
						public void actionPerformed(ActionEvent e) 
						{
							try 
							{
								mm(frame);
							} 
							catch (Exception e1) 
							{
								// TODO �Զ����ɵ� catch ��
								e1.printStackTrace();
							}
						}
		    			
		    		});*/
			ArrayList<File> fileList = getFiles("D:\\0218\\���\\1");
			//ArrayList<String> iconNameList = new ArrayList<String>();//�����ļ�������
			
			String curpath = fileList.get(0).getPath();//��ȡ�ļ�·��
		    data=readTxt(curpath);
		    pan.setChart(test.chart0(data));
		    System.out.println(fileList);
		    pan.setBounds(20, 0, 400, 400);
		    Interface.frame.add(pan);
			return pan;
		    
//			for(int i=0;i<fileList.size();i++)
//			{
//				
//			    curpath = fileList.get(i).getPath();//��ȡ�ļ�·��
//			    //iconNameList.add(curpath.substring(curpath.lastIndexOf("\\")+1));//���ļ�����������
//			    data=readTxt(curpath);
//			    pan.setChart(test.chart0(data));
//			    //ChartFrame mChartFrame = new ChartFrame("����ͼ", test.chart0(depth));
//			    //mChartFrame.setLocationRelativeTo(null);
//		        //mChartFrame.pack();
//		        //mChartFrame.setVisible(true);
//			    Thread.sleep(1000);
//			    System.out.println(curpath);
//			    pan.setBounds(0, 0, 600, 450);
//			    frame.add(pan);
//			}	
		}
		
}

 /* XYSeriesCollection mCollection = new XYSeriesCollection();
	            XYSeries mSeriesFirst = new XYSeries("First");
	            for(i=5;i<1030;i++) 
	            {
	            	mSeriesFirst.add(i-6, value[i]);
	            }
	            StandardChartTheme mChartTheme = new StandardChartTheme("CN");
	            mChartTheme.setLargeFont(new Font("����", Font.BOLD, 20));
	            mChartTheme.setExtraLargeFont(new Font("����", Font.PLAIN, 15));
	            mChartTheme.setRegularFont(new Font("����", Font.PLAIN, 15));
	            mCollection.addSeries(mSeriesFirst);
	            //�������ʽ����ChartFactory
	            ChartFactory.setChartTheme(mChartTheme);
	            //���ݷ���mCollection
	            XYSeriesCollection myCollection = mCollection;
	            //ChartFactory����mChart
	            JFreeChart mChart = ChartFactory.createXYLineChart(
	                    "����µ���������",
	                    "X-����",
	                    "Y-������",
	                    myCollection,
	                    PlotOrientation.VERTICAL,
	                    true,
	                    true,
	                    false);
	            ChartFrame mChartFrame = new ChartFrame("����ͼ", mChart);
	            mChartFrame.pack();
	            mChartFrame.setVisible(true);*/