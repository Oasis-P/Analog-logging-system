package test2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class readT {
	public static double[] readT(String filePath1){// TODO �Զ����ɵķ������ 
		double[] readT=new double[130];
		try {
            FileReader  fr=new FileReader(filePath1);
            BufferedReader bfr=new BufferedReader(fr);
            String[] s=new String[130];
            int i=0;
            String str;
            String[] st;
            while((str=bfr.readLine())!=null) {
                st=str.split(",");
                for(String j:st) {
                    s[i]=j;
                    i++;
                }
            }
            bfr.close();
            fr.close();
            for(i=0;i<130;i++) {
            	readT[i] = Double.valueOf(s[i].toString());
            }
		}
		catch (FileNotFoundException e) {// TODO Auto-generated catch block
            e.printStackTrace();
        } 
		catch (IOException e) {// TODO Auto-generated catch block
            e.printStackTrace();
        }
		return readT;
	}
}
