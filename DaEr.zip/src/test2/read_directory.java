package test2;

import java.io.File;
import java.util.ArrayList;

public class read_directory {
	public static ArrayList<File> getFiles(String path) throws Exception {
		ArrayList<File> fileList = new ArrayList<File>();
		File file = new File(path);
		if(file.isDirectory()){
		File []files = file.listFiles();
			for(File fileIndex:files){
				if(fileIndex.isDirectory()){
					getFiles(fileIndex.getPath());
				}
				else {
				fileList.add(fileIndex);
				}
			}
		}
		return fileList;
	}
}

