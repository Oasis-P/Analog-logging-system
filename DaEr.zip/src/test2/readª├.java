package test2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class read�� {
	public static double[] readtxt(String filePath1){// TODO �Զ����ɵķ������ 
		double[] value=new double[1030];
		try {
            FileReader  fr=new FileReader(filePath1);
            BufferedReader bfr=new BufferedReader(fr);
            String[] s=new String[1030];
            int i=0;
            String str;
            String[] st;
            while((str=bfr.readLine())!=null) {
                st=str.split(",");
                for(String j:st) {
                    s[i]=j;
                    i++;
                }
            }
            bfr.close();
            fr.close();
            for(i=6;i<1030;i++) {
            	value[i-6] = Double.valueOf(s[i-6].toString());
            }
		}
		catch (FileNotFoundException e) {// TODO Auto-generated catch block
            e.printStackTrace();
        } 
		catch (IOException e) {// TODO Auto-generated catch block
            e.printStackTrace();
        }
		return value;
    }
}
