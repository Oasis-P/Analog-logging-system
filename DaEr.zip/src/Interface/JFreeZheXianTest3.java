﻿package Interface;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;

import javax.swing.*;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.ui.RectangleInsets;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import test.GetFilePath;

public class JFreeZheXianTest3
{
    public static XYSeries xyCPUseries = new XYSeries("CPU");
    public static XYSeries xyCPUseries2 = new XYSeries("γ           ");//γ曲线
    public static XYSeries xyCPUseries2_1 = new XYSeries("E/T");//E/T曲线
    public static XYSeries xyCPUseries3 = new XYSeries("CPU");
    public static int hundroud = 0;
    public static int hundroud2 = 0;
    public static int hundroud3 = 0;
    //创建三个JFreeChart分别用于不同需求的绘制
    public static JFreeChart jfreechart = null;
    public static JFreeChart jfreechart2 = null;
    public static JFreeChart jfreechart3 = null;
    public static JPanel jp1;
    public static javax.swing.JButton jp1_jb1;
    public static JPanel jp2;
    public static JPanel jp3;
    public static JPanel jp4;
    public static JTextField jf1;
    public static void main(String[] args) {
        JFreeZheXianTest3 jz = new JFreeZheXianTest3();
        JFreeZheXianTest3 jz2 = new JFreeZheXianTest3();
        JFreeZheXianTest3 jz3 = new JFreeZheXianTest3();
        JFrame frame = new JFrame();
        frame.setBounds(50,200,1820,700);
        //分别创建3个Janel，用于3个JFreeChart，分别设置其大小和位置，并添加到frame中
        //为了看起来方便，分别作了3个函数。
        JPanel myjp=jz.getCPUJFreeChart();
        myjp.setBounds(0, 0, 600, 450);
        frame.getContentPane().add(myjp,null);
	
        JPanel myjp2=jz2.getCPUJFreeChart2();
        myjp2.setBounds(600, 0, 600, 450);
        frame.getContentPane().add(myjp2,null);

        JPanel myjp3=jz3.getCPUJFreeChart3();
        myjp3.setBounds(1200, 0, 600, 450);
        frame.getContentPane().add(myjp3,null);

        //创建三个JPanel，用于装载需要的其他控件组，并设置好位置，大小，添加到frame中。
        jp1 = new JPanel();
        jp1.setLayout(null);
        javax.swing.JButton  send= new javax.swing.JButton ("start draw1");
        send.setBounds(100, 80, 100, 30);
        send.setForeground(Color.BLACK);
        jp1.add(send);
        jf1 = new JTextField("111111");
        jf1.setBounds(150, 120, 150, 30);
        jp1.add(jf1);
        jf1.setBounds(150, 120, 150, 30);
        jp1.setBounds(0, 450, 600, 250);
        frame.getContentPane().add(jp1);

        jp2= new JPanel();
        jp2.setLayout(null);
        javax.swing.JButton send2=new javax.swing.JButton("start draw2");
        send2.setBounds(100, 120, 100, 30);
        send2.setForeground(Color.BLACK);
        jp2.add(send2);
        jp2.setBounds(600, 450, 600, 250);
        frame.getContentPane().add(jp2);
  //几个panel的位置有冲突，所以第三个按钮位置显示不对，自己调整
        jp3= new JPanel();
        jp3.setLayout(null);
        javax.swing.JButton send3=new javax.swing.JButton("start draw3");
        send3.setBounds(200, 120, 100, 30);
        send3.setForeground(Color.BLACK);
        jp3.add(send3);
        jp3.setBounds(1200, 450, 600, 250);
        frame.getContentPane().add(jp3);

        jp4= new JPanel();
        javax.swing.JButton send4=new javax.swing.JButton("start draw4");
        send4.setBounds(300, 120, 100, 30);
        send4.setForeground(Color.BLACK);
        jp4.add(send4);
        jp4.setBounds(600, 600, 150, 50);
        frame.getContentPane().add(jp4);
        jp4.setVisible(false);
//针对三个panel上的三个不同的按钮添加侦听器，然后分别调用不同的dynamicRun函数以示区分，也可以在函数中增加参数，根据实际需要选择怎么做。
        send.addActionListener(new ActionListener() {
       @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Runnable r = ()->{
                        dynamicRun();
                    };
                    //重启一个线程去动态绘图
                    new Thread(r).start();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });

        send2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Runnable r = ()->{
                        try {
							dynamicRun2();
						} catch (Exception e1) {
							// TODO 自动生成的 catch 块
							e1.printStackTrace();
						}
                    };
                    //重启一个线程去动态绘图
                    new Thread(r).start();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });


        send3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Runnable r = ()->{
                        dynamicRun3();
                    };
                    //重启一个线程去动态绘图
                    new Thread(r).start();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });

        frame.setVisible(true);
        frame.setLocationRelativeTo(null); // 窗口居于屏幕正中央
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
//        dynamicRun();

    }

    /**
     * 随机生成的数据
     */
    public static void dynamicRun() 
    {
        int i = 0;
        while (true) 
        {

            double factor = Math.random()*100;
            jf1.setText(String.valueOf(i));
            //hundroud = (int)factor;
            jfreechart.setTitle("1111111111");
            jfreechart.getTitle().setFont(new Font("微软雅黑", 0, 16));//设置标题字体

            xyCPUseries.add(i, factor);

            try 
            {
                Thread.currentThread();
                Thread.sleep(100);
            } 
            catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
            i++;
            if (i == 60)
            {
                i=0;
                xyCPUseries.delete(0, 59);
                continue;
            }
        }
    }

    public static void dynamicRun2() throws Exception
    {
    	double sum=0.0,sumE=0,sumT=0;int i=0,a=0;
        String[] s=new String[1030];
        String[] sE=new String[130];
        String[] sT=new String[130];
        ArrayList<File> FileList=GetFilePath.getFiles("D:\\0218\\大二\\自然γ");//γ文件
        ArrayList<File> FileListE=GetFilePath.getFiles("D:\\0218\\大二\\超热中子");//超热中子文件
		ArrayList<File> FileListT=GetFilePath.getFiles("D:\\0218\\大二\\热中子");//热中子文件
        Data[] data = new Data[FileList.size()];//γ曲线数据对象
        Data[] data2 = new Data[FileListE.size()];//E/T曲线数据对象
        jfreechart2.setTitle("Demo Two");
        jfreechart2.getTitle().setFont(new Font("微软雅黑", 0, 16));//设置标题字体
        try
        {	
        	//获取γ数据
        	for(i=(FileList.size()-1),a=0;i>=0;i--,a++)
    		{
    			String curpath = FileList.get(a).getPath();//获取文件路径
    			FileReader  fr=new FileReader(curpath); 
    			BufferedReader bfr=new BufferedReader(fr);
                int m=0;
                String str;
                String[] st;
                while((str=bfr.readLine())!=null) //读取文件内容
                {
                    st=str.split(",");
                    for(String j:st) 
                    {
                        s[m]=j;
                        m++;
                    }
                } 
                bfr.close();
                fr.close();
                for(int n=6;n<m;n++) //求和
                {sum= Double.valueOf(s[n].toString())+sum;}//转换为double类型的数据
                data[i]=new Data();//初始化，分配内存
                data[i].Value=sum;
                data[i].Depth=Double.valueOf(s[0].toString());
                System.out.println("γ："+sum+"深度"+data[i].Depth);
                sum=0; //sum初始化  
    		}
        	
        	//获取E/T数据
        	for(i=(FileListE.size()-1),a=0;i>=0;i--,a++)
    		{	
    			String curpathE = FileListE.get(a).getPath();//获取超热中子文件路径
    			FileReader  frE=new FileReader(curpathE); 
    			BufferedReader bfrE=new BufferedReader(frE);
    			
    			String curpathT = FileListT.get(a).getPath();//获取热中子文件路径
    			FileReader  frT=new FileReader(curpathT); 
    			BufferedReader bfrT=new BufferedReader(frT);
    			
                int m=0;
                String str;
                String[] stE;
                while((str=bfrE.readLine())!=null) //读取文件内容
                {
                    stE=str.split(",");
                    for(String j:stE) 
                    {
                        sE[m]=j;
                        m++;
                    }
                } 
                m=0;
                String[] stT;
                while((str=bfrT.readLine())!=null) //读取文件内容
                {
                    stT=str.split(",");
                    for(String j:stT) 
                    {
                        sT[m]=j;
                        m++;
                    }
                }
                bfrT.close();
                frT.close();
                bfrE.close();
                frE.close();
                for(int n=2;n<m;n++) //求和
                {
                	sumE= Double.valueOf(sE[n].toString())+sumE;//转换为double类型的数据
                	sumT= Double.valueOf(sT[n].toString())+sumT;
                }
                data2[i]=new Data();//初始化，分配内存
                data2[i].Value=sumE/sumT;
                data2[i].Depth=Double.valueOf(sE[0].toString());
                System.out.println("超热中子："+sumE+"热中子："+sumT+"深度："+"超热中子/热中子:"+data2[i].Value+data2[i].Depth);
                sumE=0;
                sumT=0;
            }
        } 
        catch (FileNotFoundException e) 
        {
            e.printStackTrace();
        }
        //添加γ数据和E/T数据
        if(FileList.size()>=FileListE.size())//两组数据有多有少，防止数组下标越界
	        for(i=0;i<FileList.size();i++)
	        {
	        	System.out.println("γ深度："+data[i].Depth);
	            xyCPUseries2.add(data[i].Depth,data[i].Value);
	            if(i<=FileListE.size())
	            xyCPUseries2_1.add(data2[i].Depth,data2[i].Value);//添加E/T数据
	            try 
	            {
	                Thread.currentThread();
	                Thread.sleep(100);
	            }
	            catch (InterruptedException e) 
	            {
	                e.printStackTrace();
	            }
	        }
        else
        	for(i=0;i<FileListE.size();i++)
	        {
	        	System.out.println("γ深度："+data[i].Depth);
	        	if(FileList.size()>=i)
	            xyCPUseries2.add(data[i].Depth,data[i].Value);
	            xyCPUseries2_1.add(data2[i].Depth,data2[i].Value);//添加E/T数据
	            try 
	            {
	                Thread.currentThread();
	                Thread.sleep(100);
	            }
	            catch (InterruptedException e) 
	            {
	                e.printStackTrace();
	            }
	        }
        	
    }
    public static void dynamicRun3() 
    {
        int i = 0;
        while (true) 
        {
            double factor = Math.random()*100;
            hundroud3 = (int)factor;
            jfreechart3.setTitle("33333333333");
            jfreechart3.getTitle().setFont(new Font("微软雅黑", 0, 16));//设置标题字体

            xyCPUseries3.add(i, factor);

            try 
            {
                Thread.currentThread();
                Thread.sleep(100);
            } 
            catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
            i++;
            if (i == 60)
            {
                i=0;
                xyCPUseries3.delete(0, 59);
                continue;
            }
        }
    }

    public JPanel getCPUJFreeChart()
    {

        jfreechart = ChartFactory.createXYLineChart(
                null, null, null, createDataset1(),
                PlotOrientation.VERTICAL, false, true, false);

        StandardChartTheme mChartTheme = new StandardChartTheme("CN");
        mChartTheme.setLargeFont(new Font("黑体", Font.BOLD, 20));
        mChartTheme.setExtraLargeFont(new Font("宋体", Font.PLAIN, 15));
        mChartTheme.setRegularFont(new Font("宋体", Font.PLAIN, 15));
        //ChartFactory.setChartTheme(mChartTheme);

        jfreechart.setBorderPaint(new Color(0,204,205));
        jfreechart.setBorderVisible(true);

        XYPlot xyplot = (XYPlot) jfreechart.getPlot();

        // Y轴
        NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
        //numberaxis.setTickUnit(new NumberTickUnit(100d));
        // 只显示整数值
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        // numberaxis.setAutoRangeIncludesZero(true);
        numberaxis.setLowerMargin(0); // 数据轴下（左）边距 ­
        //numberaxis.setMinorTickMarksVisible(false);// 标记线是否显示
        numberaxis.setTickMarkInsideLength(0);// 外刻度线向内长度
        numberaxis.setTickMarkOutsideLength(0);

        // X轴的设计
        NumberAxis x = (NumberAxis) xyplot.getDomainAxis();
        x.setAutoRange(true);// 自动设置数据轴数据范围
        // 自己设置横坐标的值
        x.setAutoTickUnitSelection(false);
        x.setTickUnit(new NumberTickUnit(60d));
        // 设置最大的显示值和最小的显示值
        //x.setLowerBound(0);
        //x.setUpperBound(60);
        // 数据轴的数据标签：只显示整数标签
        x.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        x.setAxisLineVisible(true);// X轴竖线是否显示
        x.setTickMarksVisible(false);// 标记线是否显示

        RectangleInsets offset = new RectangleInsets(0, 0, 0, 0);
        //xyplot.setAxisOffset(offset);// 坐标轴到数据区的间距
        xyplot.setBackgroundAlpha(0.0f);// 去掉柱状图的背景色
        xyplot.setOutlinePaint(null);// 去掉边框

        // ChartPanel chartPanel = new ChartPanel(jfreechart);
        // chartPanel.restoreAutoDomainBounds();//重置X轴

        ChartPanel chartPanel = new ChartPanel(jfreechart, true);

        return chartPanel;
    }

    public JPanel getCPUJFreeChart2()
    {
        jfreechart2 = ChartFactory.createXYLineChart(
                null, "Depth", "γ", createDataset2(),
                PlotOrientation.VERTICAL, true, true, false);
        StandardChartTheme mChartTheme = new StandardChartTheme("CN");
        mChartTheme.setLargeFont(new Font("黑体", Font.BOLD, 20));
        mChartTheme.setExtraLargeFont(new Font("宋体", Font.PLAIN, 15));
        mChartTheme.setRegularFont(new Font("宋体", Font.PLAIN, 15));
        //ChartFactory.setChartTheme(mChartTheme);

        jfreechart2.setBorderPaint(new Color(0,204,205));
        jfreechart2.setBorderVisible(true);

        XYPlot xyplot = (XYPlot) jfreechart2.getPlot();

        // Y轴
        NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
        //numberaxis.setLowerBound(0);
        //numberaxis.setUpperBound(100);
       // numberaxis.setTickUnit(new NumberTickUnit(100d));
        // 只显示整数值
        //numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        // numberaxis.setAutoRangeIncludesZero(true);
        numberaxis.setLowerMargin(0); // 数据轴下（左）边距 ­
        //numberaxis.setMinorTickMarksVisible(false);// 标记线是否显示
        numberaxis.setTickMarkInsideLength(0);// 外刻度线向内长度
        numberaxis.setTickMarkOutsideLength(0);
        // X轴的设计
        NumberAxis x = (NumberAxis) xyplot.getDomainAxis();
        x.setAutoRange(true);// 自动设置数据轴数据范围
        // 自己设置横坐标的值
        x.setAutoTickUnitSelection(false);
        x.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        x.setAxisLineVisible(true);// X轴竖线是否显示
        x.setTickMarksVisible(false);// 标记线是否显示

//添加第二个Y轴
        NumberAxis   numberaxis1   =   new   NumberAxis( "E/T"); 
        numberaxis1.setAutoRangeIncludesZero(false);
        
        numberaxis1.setAxisLinePaint(Color.red);
        numberaxis1.setLabelPaint(Color.red);
        numberaxis1.setTickLabelPaint(Color.red);
        xyplot.setRangeAxis(1,numberaxis1);  //设置Y轴
        xyplot.setDataset(1,createDataset2_1()); //添加数据集合
        xyplot.mapDatasetToRangeAxis(1,1); 
       // RectangleInsets offset = new RectangleInsets(0, 0, 0, 0);
       // xyplot.setAxisOffset(offset);// 坐标轴到数据区的间距
        xyplot.setBackgroundAlpha(0.0f);// 去掉柱状图的背景色
        xyplot.setOutlinePaint(null);// 去掉边框
        
        XYLineAndShapeRenderer   xylineandshaperenderer=(XYLineAndShapeRenderer)xyplot.getRenderer(); 
        StandardXYToolTipGenerator.getTimeSeriesInstance(); 
        xylineandshaperenderer.setSeriesPaint(0, Color.black);
        XYLineAndShapeRenderer   xylineandshaperenderer1   =   new   XYLineAndShapeRenderer(true,   false); 
        xylineandshaperenderer1.setSeriesPaint(0, Color.red); 
        xyplot.setRenderer(1,   xylineandshaperenderer1); 
        // ChartPanel chartPanel = new ChartPanel(jfreechart);
        // chartPanel.restoreAutoDomainBounds();//重置X轴

        ChartPanel chartPanel = new ChartPanel(jfreechart2, true);

        return chartPanel;
    }
    
    public JPanel getCPUJFreeChart3()
    {

        jfreechart3 = ChartFactory.createXYLineChart(
                null, null, null, createDataset3(),
                PlotOrientation.VERTICAL, false, true, false);

        StandardChartTheme mChartTheme = new StandardChartTheme("CN");
        mChartTheme.setLargeFont(new Font("黑体", Font.BOLD, 20));
        mChartTheme.setExtraLargeFont(new Font("宋体", Font.PLAIN, 15));
        mChartTheme.setRegularFont(new Font("宋体", Font.PLAIN, 15));
       // ChartFactory.setChartTheme(mChartTheme);

        jfreechart3.setBorderPaint(new Color(0,204,205));
        jfreechart3.setBorderVisible(true);

        XYPlot xyplot = (XYPlot) jfreechart3.getPlot();

        // Y轴
        NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
        numberaxis.setLowerBound(0);
        numberaxis.setUpperBound(100);
        numberaxis.setTickUnit(new NumberTickUnit(100d));
        // 只显示整数值
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        // numberaxis.setAutoRangeIncludesZero(true);
        numberaxis.setLowerMargin(0); // 数据轴下（左）边距 ­
        //numberaxis.setMinorTickMarksVisible(false);// 标记线是否显示
        numberaxis.setTickMarkInsideLength(0);// 外刻度线向内长度
        numberaxis.setTickMarkOutsideLength(0);

        // X轴的设计
        NumberAxis x = (NumberAxis) xyplot.getDomainAxis();
        x.setAutoRange(true);// 自动设置数据轴数据范围
        // 自己设置横坐标的值
        x.setAutoTickUnitSelection(false);
        x.setTickUnit(new NumberTickUnit(60d));
        // 设置最大的显示值和最小的显示值
        x.setLowerBound(0);
        x.setUpperBound(60);
        // 数据轴的数据标签：只显示整数标签
        x.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        x.setAxisLineVisible(true);// X轴竖线是否显示
        x.setTickMarksVisible(false);// 标记线是否显示

        //RectangleInsets offset = new RectangleInsets(0, 0, 0, 0);
        //xyplot.setAxisOffset(offset);// 坐标轴到数据区的间距
        xyplot.setBackgroundAlpha(0.0f);// 去掉柱状图的背景色
        xyplot.setOutlinePaint(null);// 去掉边框

        // ChartPanel chartPanel = new ChartPanel(jfreechart);
        // chartPanel.restoreAutoDomainBounds();//重置X轴

        ChartPanel chartPanel = new ChartPanel(jfreechart3, true);

        return chartPanel;
    }
    /**
     * 该方法是数据的设计
     */
    public static XYDataset createDataset1() 
    {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(xyCPUseries);
        return xyseriescollection;
    }
    public static XYDataset createDataset2() 
    {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(xyCPUseries2);
        return xyseriescollection;
    }
    public static XYDataset createDataset2_1() //第二个Y轴的XYDataset
    {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(xyCPUseries2_1);
        return xyseriescollection;
    }
    public static XYDataset createDataset3() 
    {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(xyCPUseries3);
        return xyseriescollection;
    }
}

