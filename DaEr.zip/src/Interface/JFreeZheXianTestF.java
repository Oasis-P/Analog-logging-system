package Interface;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.ui.RectangleInsets;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import test2.readE;
import test2.readT;
import test2.read_directory;
import test2.readγ;

public class JFreeZheXianTestF{
	//gama组件初始化
	public static JLabel jp1_jl1;
	public static JLabel jp1_jl2;
	public static JTextField jp1_jt1;
	public static JLabel jp1_jl3;
	public static JLabel jp1_jl6;
	public static String string[] = {"1","2","3","4","5"};
	public static JLabel jp1_jl4;
	public static JTextField jp1_jt3;
	public static JLabel jp1_jl5;
	public static JTextField jp1_jt4;
	public static JLabel jp1_jl7;
	public static JLabel jp1_jl8;
	public static JTextArea jp1_jta2;
	public static JTextArea jp1_jta3;
	public static JButton jp1_jb1;
	public static JButton jp1_jb2;
	public static JTextArea jp1_jta1;
	public static JComboBox<String> comboBox1;
	public static ComboBoxModel comboBoxModel;
	public static String gama_dir;//γ文件夹目录
	public static String gama_interval;//读取γ文件的时间间隔
	public static String gama_daoci1;//道次1
	public static String gama_daoci2;//道次2
	public static String gama_e_t_temperature;//γ探管温度
	public static String gama_sum;//道次1至道次2的伽玛粒子总数
	public static Integer gamafilesize;//道次1至道次2的伽玛粒子总数
	//ET组件初始化
	public static JLabel jp3_jl1;
	public static JLabel jp3_jl2;
	public static JTextField jp3_jt1;
	public static JLabel jp3_jl3;
	public static JTextField jp3_jt2;
	public static JLabel jp3_jl4;
	public static JTextArea jp3_jta3;
	public static JLabel jp3_jl5;
	public static JTextArea jp3_jta4;
	public static JLabel jp3_jl6;
	public static JTextArea jp3_jta2;
	public static JLabel jp3_jl7;
	public static JComboBox<String> comboBox2;
	public static JButton jp3_jb1;
	public static JButton jp3_jb2;
	public static ComboBoxModel comboBoxMode2;
	public static JTextField jp3_jt3;//E道次
	public static JTextField jp3_jt4;
	public static JLabel jp3_jl8;//道次选择
	public static JLabel jp3_jl9;//至
	public static JTextField jp3_jt5;//T道次
	public static JTextField jp3_jt6;
	public static JLabel jp3_jl10;//道次选择
	public static JLabel jp3_jl11;//至道次选择
	public static JLabel jp3_jl12;//当前深度
	public static JTextArea jp3_jta5;
	public static String E_dir;//超热中子文件夹目录
	public static String T_dir;//热中子文件夹目录
	public static String ET_interval;//读取ET文件的时间间隔
	public static String E_sum;//道次1至道次2的伽玛粒子总数
	public static String T_sum;//道次1至道次2的伽玛粒子总数
	public static String E_daoci1;//道次1
	public static String E_daoci2;//道次2
	public static String T_daoci1;//道次1
	public static String T_daoci2;//道次2
	public static int flag1 = 0;
	public static int flag2 = 0;
	public static int flag3 = 0;
	static double[] data=new double[1030];
	static double[] dataE=new double[131];
	static double[] dataT=new double[131];
	static double[] data2=new double[1030];
	static double[] dataE2=new double[131];
	static double[] dataT2=new double[131];
    public static XYSeries XYDATAS = new XYSeries("JP1");
    public static XYSeries XYDATAS2 = new XYSeries("Depth");
    public static XYSeries XYDATAS3 = new XYSeries("E");
    public static XYSeries XYDATAS4 = new XYSeries("T");
    public static XYSeries XYDATAS5 = new XYSeries("E/T");
    public static XYSeries XYDATAS6 = new XYSeries("Number   of   Gamma   Particles");
    //JP2组件初始化
    public static JButton jp2_jb1;
    //创建三个JFreeChart分别用于不同需求的绘制
    public static JFreeChart jfreechart = null;
    public static JFreeChart jfreechart2 = null;
    public static JFreeChart jfreechart3 = null;
    public static JPanel jp1;
    public static JPanel jp2;
    public static JPanel jp3;
    
    public static void main(String[] args) {
    	FontUIResource fontRes = new FontUIResource(new Font("微软雅黑",Font.PLAIN,16)); 
		for (Enumeration<Object> keys = UIManager.getDefaults().keys();keys.hasMoreElements();) { 
			Object key = keys.nextElement(); 
			Object value = UIManager.get(key); 
			if (value instanceof FontUIResource) { 
				UIManager.put(key, fontRes); 
			} 
		}
        JFreeZheXianTest jz = new JFreeZheXianTest();
        JFreeZheXianTest jz2 = new JFreeZheXianTest();
        JFreeZheXianTest jz3 = new JFreeZheXianTest();
        JFrame frame = new JFrame("模拟测井系统");
        frame.setBounds(40,200,1860,825);
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		
        //分别创建3个Janel，用于3个JFreeChart，分别设置其大小和位置，并添加到frame中
        //为了看起来方便，分别作了3个函数。
        JPanel myjp=jz.getCPUJFreeChart();
        myjp.setBounds(410, 4, 600, 350);//10, 4, 600, 450
        frame.getContentPane().add(myjp,null);
		
        JPanel myjp2=jz2.getCPUJFreeChart2();
        myjp2.setBounds(1020, 4, 550, 700);
        frame.getContentPane().add(myjp2,null);

        JPanel myjp3=jz3.getCPUJFreeChart3();
        myjp3.setBounds(410, 420-50, 600, 400);
        frame.getContentPane().add(myjp3,null);

        //创建三个JPanel，用于装载需要的其他控件组，并设置好位置，大小，添加到frame中。
        jp1 = new JPanel();
        jp1.setLayout(null);
        jp1.setBounds(10, 4, 400, 350);
        jp1_jl1 = new JLabel("自    然     γ    能    谱");
		jp1_jl1.setBounds(120, 30+10, 200, 30);
		jp1_jl1.setForeground(Color.BLACK);
		jp1.add(jp1_jl1);
		jp1_jl2 = new JLabel("文件夹路径：");
		jp1_jl2.setBounds(10+9, 55+20+20, 100, 30);
		jp1_jl2.setForeground(Color.BLACK);
		jp1.add(jp1_jl2);
		jp1_jt1 = new JTextField();
		jp1_jt1.setBounds(105+5, 55+20+20, 280, 30);
		jp1.add(jp1_jt1);
		jp1_jl3 = new JLabel("时间间隔(s):");
		jp1_jl3.setBounds(10+9, 95+20+20+20, 100, 30);
		jp1_jl3.setForeground(Color.BLACK);
		jp1.add(jp1_jl3);
	    String string[] = {"1","2","3","4","5"};
		comboBox1 = new JComboBox<>();
		comboBoxModel = new DefaultComboBoxModel<>(string);
		comboBox1.setBounds(105+5, 100+20+20+20, 50, 25);
		comboBox1.setModel(comboBoxModel);
		comboBox1.setEditable(true);
		jp1.add(comboBox1);
		jp1_jl4 = new JLabel("道次选择：");
		jp1_jl4.setBounds(210-40, 95+20+20+20, 100, 30);
		jp1_jl4.setForeground(Color.BLACK);
		jp1.add(jp1_jl4);
		jp1_jt3 = new JTextField();
		jp1_jt3.setBounds(290-40, 95+20+20+20, 50, 30);
		jp1_jt3.setForeground(Color.BLACK);
		jp1.add(jp1_jt3);
		jp1_jl5 = new JLabel("至");
		jp1_jl5.setBounds(350-40, 95+20+20+20, 50, 30);
		jp1_jl5.setForeground(Color.BLACK);
		jp1.add(jp1_jl5);
		jp1_jt4 = new JTextField();
		jp1_jt4.setBounds(380-40, 95+20+20+20, 50, 30);
		jp1_jt4.setForeground(Color.BLACK);
		jp1.add(jp1_jt4);
		jp1_jl8 = new JLabel("当前深度(m):");
		jp1_jl8.setBounds(33+5+2+1+1-20-10, 135+20+20+20+20, 100, 30);
		jp1_jl8.setForeground(Color.BLACK);
		jp1.add(jp1_jl8);
		jp1_jta3 = new JTextArea();
		jp1_jta3.setBounds(105+5, 135+20+20+20+20, 80, 25);
		jp1_jta3.setForeground(Color.BLACK);
		jp1_jta3.setEditable(false);
		jp1.add(jp1_jta3);
		jp1_jl6 = new JLabel("伽马总数:");
		jp1_jl6.setBounds(210+20, 135+20+20+20+20, 80, 25);
		jp1_jl6.setForeground(Color.BLACK);
		jp1.add(jp1_jl6);
		jp1_jta1 = new JTextArea();
		jp1_jta1.setBounds(290+20, 135+20+20+20+20, 80, 25);
		jp1_jta1.setForeground(Color.BLACK);
		jp1_jta1.setEditable(false);
		jp1.add(jp1_jta1);
		jp1_jl7 = new JLabel("探管温度(℃):");
		jp1_jl7.setBounds(10, 175+20+80, 100, 25);
		jp1_jl7.setForeground(Color.BLACK);
		jp1.add(jp1_jl7);
		jp1_jta2 = new JTextArea();
		jp1_jta2.setBounds(110, 175+20+80, 50, 25);
		jp1_jta2.setForeground(Color.BLACK);
		jp1_jta2.setEditable(false);
		jp1.add(jp1_jta2);
		jp1_jb1 = new JButton("开始模拟");
		jp1_jb1.setBounds(165+5+5, 175+20+80, 100, 30);
		jp1_jb1.setForeground(Color.BLACK);
		jp1.add(jp1_jb1);
		jp1_jb2 = new JButton("结束模拟");
		jp1_jb2.setBounds(290, 175+20+80, 100, 30);
		jp1_jb2.setForeground(Color.BLACK);
		jp1.add(jp1_jb2);
        frame.getContentPane().add(jp1);
      //几个panel的位置有冲突，所以第三个按钮位置显示不对，自己调整
        jp3= new JPanel();
        jp3.setLayout(null);
        jp3.setBounds(0, 404, 400, 350);
        jp3_jl1 = new JLabel("超 热 中 子（E）、热 中 子 （T）能 谱");
		jp3_jl1.setBounds(50, 10, 300, 30);
		jp3_jl1.setForeground(Color.BLACK);
		jp3.add(jp3_jl1);
		jp3_jl2 = new JLabel("(E)文件夹路径：");
		jp3_jl2.setBounds(10, 60, 120, 30);
		jp3_jl2.setForeground(Color.BLACK);
		jp3.add(jp3_jl2);
		jp3_jt1 = new JTextField();
		jp3_jt1.setBounds(125, 60, 265+10, 30);
		jp3.add(jp3_jt1);
		jp3_jl3 = new JLabel("(T)文件夹路径：");
		jp3_jl3.setBounds(10, 110, 275, 30);
		jp3_jl3.setForeground(Color.BLACK);
		jp3.add(jp3_jl3);
		jp3_jt2 = new JTextField();
		jp3_jt2.setBounds(125, 110, 275, 30);
		jp3.add(jp3_jt2);
		jp3_jl8 = new JLabel("(E)道次选择：");
		jp3_jl8.setBounds(26, 165, 100, 30);
		jp3_jl8.setForeground(Color.BLACK);
		jp3.add(jp3_jl8);
		jp3_jt3 = new JTextField();
		jp3_jt3.setBounds(126, 165, 50, 30);
		jp3.add(jp3_jt3);
		jp3_jl9 = new JLabel("至");
		jp3_jl9.setForeground(Color.BLACK);
		jp3_jl9.setBounds(180, 165, 50, 30);
		jp3.add(jp3_jl9);
		jp3_jt4 = new JTextField();
		jp3_jt4.setBounds(200, 165, 50, 30);
		jp3.add(jp3_jt4);
		jp3_jl4 = new JLabel("E总数:");
		jp3_jl4.setBounds(260, 165, 60, 30);
		jp3_jl4.setForeground(Color.BLACK);
		jp3.add(jp3_jl4);
		jp3_jta3 = new JTextArea();
		jp3_jta3.setBounds(320, 165, 80, 25);
		jp3_jta3.setForeground(Color.BLACK);
		jp3_jta3.setEditable(false);
		jp3.add(jp3_jta3);
		jp3_jl10 = new JLabel("(T)道次选择：");
		jp3_jl10.setForeground(Color.BLACK);
		jp3_jl10.setBounds(26, 230-20, 100, 30);
		jp3.add(jp3_jl10);
		jp3_jt5 = new JTextField();
		jp3_jt5.setBounds(126, 230-20, 50, 30);
		jp3.add(jp3_jt5);
		jp3_jl11 = new JLabel("至");
		jp3_jl11.setForeground(Color.BLACK);
		jp3_jl11.setBounds(180, 230-20, 50, 30);
		jp3.add(jp3_jl11);
		jp3_jt6 = new JTextField();
		jp3_jt6.setBounds(200, 230-20, 50, 30);
		jp3.add(jp3_jt6);
		jp3_jl5 = new JLabel("T总数:");
		jp3_jl5.setBounds(260, 230-20, 60, 30);
		jp3_jl5.setForeground(Color.BLACK);
		jp3.add(jp3_jl5);
		jp3_jta4 = new JTextArea();		
		jp3_jta4.setBounds(320, 233-20, 80, 25);
		jp3_jta4.setForeground(Color.BLACK);
		jp3_jta4.setEditable(false);
		jp3.add(jp3_jta4);
		jp3_jl7 = new JLabel("时间间隔(s)：");
		jp3_jl7.setBounds(26, 210+30+5+10, 100, 30);
		jp3_jl7.setForeground(Color.BLACK);
		jp3.add(jp3_jl7);
		comboBox2 = new JComboBox<>();
		comboBoxMode2 = new DefaultComboBoxModel<>(string);
		comboBox2.setBounds(126, 210+30+5+10+3, 50, 25);
		comboBox2.setModel(comboBoxMode2);
		comboBox2.setEditable(true);
		jp3.add(comboBox2);
		jp3_jl12 = new JLabel("当前深度(m):");
		jp3_jl12.setBounds(210+5-3, 210+30+5+10, 100, 30);
		jp3_jl12.setForeground(Color.BLACK);
		jp3.add(jp3_jl12);
		jp3_jta5 = new JTextArea();
		jp3_jta5.setBounds(320, 210+30+5+10+3, 100, 25);
		jp3.add(jp3_jta5);
		jp3_jl6 = new JLabel("探管温度(℃):");
		jp3_jl6.setBounds(20, 250+50, 116, 30);
		jp3_jl6.setForeground(Color.BLACK);
		jp3.add(jp3_jl6);
		jp3_jta2 = new JTextArea();
		jp3_jta2.setBounds(126, 250+50+3, 50, 25);
		jp3_jta2.setForeground(Color.BLACK);
		jp3_jta2.setEditable(false);
		jp3.add(jp3_jta2);
		jp3_jb1 = new JButton("开始模拟");
		jp3_jb1.setBounds(190, 250+50, 100, 30);
		jp3_jb1.setForeground(Color.BLACK);
        jp3.add(jp3_jb1);
        jp3_jb2 = new JButton("结束模拟");
		jp3_jb2.setBounds(300, 250+50, 100, 30);
		jp3_jb2.setForeground(Color.BLACK);
        jp3.add(jp3_jb2);
        frame.getContentPane().add(jp3);
        //
        jp2= new JPanel();
        jp2.setLayout(null);
        jp2_jb1 = new JButton("开始模拟");
        jp2_jb1.setBounds(150+1010, 710, 100, 30);
        jp2_jb1.setForeground(Color.BLACK);
        jp2.add(jp2_jb1);
        jp2.setBounds(1010, 700, 600, 50);
        frame.getContentPane().add(jp2);
        
        
  

//针对三个panel上的三个不同的按钮添加侦听器，然后分别调用不同的dynamicRun函数以示区分，也可以在函数中增加参数，根据实际需要选择怎么做。
        jp1_jb1.addActionListener(new ActionListener() {
       @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Runnable r = ()->{
                    	System.out.println("即将执行");
                        dynamicRun();
                    };
                    //重启一个线程去动态绘图
                    new Thread(r).start();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });

        jp2_jb1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Runnable r = ()->{
                        dynamicRun2();
                    };
                    //重启一个线程去动态绘图
                    new Thread(r).start();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });


        jp3_jb1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Runnable r = ()->{
                        dynamicRun3();
                    };
                    //重启一个线程去动态绘图
                    new Thread(r).start();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });

        frame.setVisible(true);
        frame.setLocationRelativeTo(null); // 窗口居于屏幕正中央
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    /**
     * 随机生成的数据
     */
    public static void dynamicRun() {
    	flag1 = 0;
    	gama_dir=jp1_jt1.getText();
		gama_interval=(String) comboBox1.getSelectedItem();
		gama_daoci1=jp1_jt3.getText();
		gama_daoci2=jp1_jt4.getText();
		if (gama_daoci2.equals("") || gama_daoci1.equals("") || Integer.parseInt(gama_daoci2)  <= Integer.parseInt(gama_daoci1) || gama_dir.equals("")) {
			JOptionPane.showMessageDialog(null, "道次1、道次2、文件夹路径均不能为空\n            道次2必须大于道次1！");
		}else{
			try {
				System.out.println("if succ/n");
				ArrayList<File> fileList;
				fileList = read_directory.getFiles(gama_dir);
				System.out.println("filelis succ/n");
			    for(int i=0;i<fileList.size();i++){
			    	String curpath = fileList.get(i).getPath();//获取文件路径
				    data=readγ.readtxt(curpath);
			    	double temp=0;
			    	for(int j=Integer.parseInt(gama_daoci1);j<=Integer.parseInt(gama_daoci2);j++) {
						temp=data[j+5]+temp;
					}
			    	for (int j = 6; j < data.length; j++) {
			    		XYDATAS.add(j-6, data[j]);
			    		System.out.println(i+" "+data[j]);
					}
			    	gama_sum=String.valueOf(temp);
			    	jp1_jta1.setText(gama_sum);//获取伽马总数
			    	jp1_jta2.setText(String.valueOf(data[2]));
			    	jp1_jta3.setText(String.valueOf(data[0]));
			    	try {
			    		Thread.currentThread();
						Thread.sleep(Integer.parseInt(gama_interval)*1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
			    	jp1_jb2.addActionListener(new ActionListener() {
    		            @Override
    		            public void actionPerformed(ActionEvent e) {
    		            	 flag1 = 1;
    		            }
    		        });
					if(flag1 == 1) {
						JOptionPane.showMessageDialog(null, "γ模拟结束");
			    		break;
			    	}
					else if(i != fileList.size()-1) {
			    		XYDATAS.delete(0, data.length-7);
			    	}
			    	
			    }
			} catch (Exception e) {}
		}
    }
    public static void dynamicRun3() {
    	flag3 = 0;
    	E_dir=jp3_jt1.getText();
    	T_dir=jp3_jt2.getText();
    	E_daoci1=jp3_jt3.getText();
    	E_daoci2=jp3_jt4.getText();
    	T_daoci1=jp3_jt5.getText();
    	T_daoci2=jp3_jt6.getText();
    	ET_interval=(String) comboBox2.getSelectedItem();
    	if (E_dir.equals("") || T_dir.equals("")) {
    		JOptionPane.showMessageDialog(null, "请输入E和T文件夹路径！");
		}else if (Integer.parseInt(E_daoci2)<=Integer.parseInt(E_daoci1)||Integer.parseInt(T_daoci2)<=Integer.parseInt(T_daoci1)
				||E_daoci1.equals("")||E_daoci2.equals("")||T_daoci1.equals("")||T_daoci2.equals("")) {
			JOptionPane.showMessageDialog(null, "道次2必须大于道次1且均不为空！");
		}else{
			try {
				ArrayList<File> fileList1,fileList2;
				fileList1 = read_directory.getFiles(E_dir);
				fileList2 = read_directory.getFiles(T_dir);
				for(int i=0;i<fileList1.size();i++){
			    	String curpath1 = fileList1.get(i).getPath();//获取文件路径
			    	String curpath2 = fileList2.get(i).getPath();//获取文件路径
				    try {
				    	dataE=readE.readE(curpath1);
					    dataT=readT.readT(curpath2);
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "请重新确认路径是否属于E和T文件路径！");
					}
			    	double Etemp=0,Ttemp=0;
			    	for(int j=Integer.parseInt(E_daoci1);j<=Integer.parseInt(E_daoci2);j++) {
						Etemp=dataE[j+1]+Etemp;
					}
			    	for(int j=Integer.parseInt(T_daoci1);j<=Integer.parseInt(T_daoci2);j++) {
						Ttemp=dataT[j+1]+Ttemp;
					}
			    	E_sum=String.valueOf(Etemp);
			    	T_sum=String.valueOf(Ttemp);
			    	for (int j = 2; j < dataE.length; j++) {
			    		XYDATAS3.add(j-2, dataE[j]);
			    		XYDATAS4.add(j-2, dataT[j]);
					}
			    	jp3_jta3.setText(E_sum);//获取E总数
			    	jp3_jta4.setText(T_sum);//获取T总数
			    	jp3_jta2.setText(String.valueOf(dataT[1]));
			    	jp3_jta5.setText(String.valueOf(dataT[0]));
			    	try {
			    		Thread.currentThread();
						Thread.sleep(Integer.parseInt(ET_interval)*1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
			    	jp3_jb2.addActionListener(new ActionListener() {
			            @Override
			            public void actionPerformed(ActionEvent e) {
			            	 flag3 = 1;
			            }
			        });
					if(flag3 == 1) {
						JOptionPane.showMessageDialog(null, "E、T模拟结束");
			    		break;
			    	}
					else if(i != fileList1.size()-1) {
			    		XYDATAS3.delete(0, dataE.length-3);
			    		XYDATAS4.delete(0, dataT.length-3);
			    	}
			    }
			} catch (Exception e1) {
				
			}
		}
    }
//    jfreechart2.setTitle("2222222222222222");
//    jfreechart2.getTitle().setFont(new Font("微软雅黑", 0, 16));//设置标题字体
//    XYDATAS2.add(i, factor);
//    XYDATAS2.delete(0, 59);
    public static void dynamicRun2()  {
    	E_dir=jp3_jt1.getText();
    	T_dir=jp3_jt2.getText();
    	E_daoci1=jp3_jt3.getText();
    	E_daoci2=jp3_jt4.getText();
    	T_daoci1=jp3_jt5.getText();
    	T_daoci2=jp3_jt6.getText();
    	gama_dir=jp1_jt1.getText();
		gama_daoci1=jp1_jt3.getText();
		gama_daoci2=jp1_jt4.getText();
		try {
			ArrayList<File> fileList1,fileList2,fileList3;
			fileList1 = read_directory.getFiles(E_dir);
			fileList2 = read_directory.getFiles(T_dir);
			fileList3 = read_directory.getFiles(gama_dir);
			for(int i=0;i<fileList1.size();i++){
		    	String curpath1 = fileList1.get(i).getPath();//获取文件路径
		    	String curpath2 = fileList2.get(i).getPath();//获取文件路径
		    	String curpath3 = fileList3.get(i).getPath();//获取文件路径
		    	dataE2=readE.readE(curpath1);
			    dataT2=readT.readT(curpath2);
			    double Etemp=0,Ttemp=0;
		    	for(int j=Integer.parseInt(E_daoci1);j<=Integer.parseInt(E_daoci2);j++) {
					Etemp=dataE2[j+1]+Etemp;
				}
		    	for(int j=Integer.parseInt(T_daoci1);j<=Integer.parseInt(T_daoci2);j++) {
					Ttemp=dataT2[j+1]+Ttemp;
				}
		    	XYDATAS5.add(i+400, Etemp/Ttemp);//e/t
		    	data2=readγ.readtxt(curpath3);
		    	double temp=0;
		    	for(int j=Integer.parseInt(gama_daoci1);j<=Integer.parseInt(gama_daoci2);j++) {
					temp=data2[j+5]+temp;
					System.out.println(temp+"/n");
				}
		    	XYDATAS6.add(i+400, temp);//sumgama
		    	XYDATAS2.add(i+400, data2[0]);//depth
			}
		}catch (Exception e) {
			// TODO: handle exception
		}  
    }

    

    public JPanel getCPUJFreeChart(){

        jfreechart = ChartFactory.createXYLineChart(
                null, "Gates", "Number   of   Gamma   Particles", createDataset1(),
                PlotOrientation.VERTICAL, false, true, false);

        StandardChartTheme mChartTheme = new StandardChartTheme("CN");
        mChartTheme.setLargeFont(new Font("黑体", Font.BOLD, 20));
        mChartTheme.setExtraLargeFont(new Font("宋体", Font.PLAIN, 15));
        mChartTheme.setRegularFont(new Font("宋体", Font.PLAIN, 15));
        ChartFactory.setChartTheme(mChartTheme);

        jfreechart.setBorderPaint(new Color(0,204,205));
        jfreechart.setBorderVisible(true);

        XYPlot xyplot = (XYPlot) jfreechart.getPlot();

        // Y轴
        NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
//        numberaxis.setLowerBound(0);
//        numberaxis.setUpperBound(900);
        numberaxis.setTickUnit(new NumberTickUnit(200d));
        // 只显示整数值
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        // numberaxis.setAutoRangeIncludesZero(true);
        numberaxis.setLowerMargin(0); // 数据轴下（左）边距 ­
        numberaxis.setMinorTickMarksVisible(false);// 标记线是否显示
        numberaxis.setTickMarkInsideLength(0);// 外刻度线向内长度
        numberaxis.setTickMarkOutsideLength(0);

        // X轴的设计
        NumberAxis x = (NumberAxis) xyplot.getDomainAxis();
        x.setAutoRange(false);// 自动设置数据轴数据范围
        // 自己设置横坐标的值
        x.setAutoTickUnitSelection(true);
        x.setTickUnit(new NumberTickUnit(100d));
        // 设置最大的显示值和最小的显示值
        x.setLowerBound(0);
        x.setUpperBound(1030);
        // 数据轴的数据标签：只显示整数标签
        x.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        x.setAxisLineVisible(true);// X轴竖线是否显示
        x.setTickMarksVisible(false);// 标记线是否显示

        RectangleInsets offset = new RectangleInsets(0, 0, 0, 0);
        xyplot.setAxisOffset(offset);// 坐标轴到数据区的间距
        xyplot.setBackgroundAlpha(0.0f);// 去掉柱状图的背景色
        xyplot.setOutlinePaint(null);// 去掉边框

        // ChartPanel chartPanel = new ChartPanel(jfreechart);
        // chartPanel.restoreAutoDomainBounds();//重置X轴

        ChartPanel chartPanel = new ChartPanel(jfreechart, true);

        return chartPanel;
    }

    
    
    public JPanel getCPUJFreeChart2(){

        jfreechart2 = ChartFactory.createXYLineChart(
                null, "Depth", "E/T", createDataset5(),
                PlotOrientation.HORIZONTAL, false, true, false);

        StandardChartTheme mChartTheme = new StandardChartTheme("CN");
        mChartTheme.setLargeFont(new Font("黑体", Font.BOLD, 20));
        mChartTheme.setExtraLargeFont(new Font("宋体", Font.PLAIN, 15));
        mChartTheme.setRegularFont(new Font("宋体", Font.PLAIN, 15));
        ChartFactory.setChartTheme(mChartTheme);

        jfreechart2.setBorderPaint(new Color(0,204,205));
        jfreechart2.setBorderVisible(true);

        XYPlot xyplot = (XYPlot) jfreechart2.getPlot();

        
        // x轴
        NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
        numberaxis.setTickUnit(new NumberTickUnit(0.1d));
        // 只显示整数值
        
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        numberaxis.setLowerMargin(0); // 数据轴下（左）边距 ­
        numberaxis.setMinorTickMarksVisible(false);// 标记线是否显示
        numberaxis.setTickMarkInsideLength(0);// 外刻度线向内长度
        numberaxis.setTickMarkOutsideLength(0);
        numberaxis.setLowerBound(0);
        numberaxis.setUpperBound(1);
        numberaxis.setAxisLinePaint(Color.RED);
        numberaxis.setLabelPaint(Color.RED);
        numberaxis.setTickLabelPaint(Color.RED);
//        xyplot.setDomainAxis(1,numberaxis);  //设置Y轴
//        xyplot.setDataset(1,createDataset5()); //添加数据集合
//        xyplot.mapDatasetToRangeAxis(1,1); 
//        xyplot.setBackgroundAlpha(0.0f);// 去掉柱状图的背景色
//        xyplot.setOutlinePaint(null);// 去掉边框
        //第二个x轴
        NumberAxis   numberaxis1   =   new   NumberAxis("Number  of  Gama  Particles"); 
        numberaxis1.setAutoRangeIncludesZero(false);
        numberaxis1.setAxisLinePaint(Color.BLUE);
        numberaxis1.setLabelPaint(Color.BLUE);
        numberaxis1.setTickLabelPaint(Color.BLUE);
//        numberaxis1.setAutoRange(true);// 自动设置数据轴数据范围
        numberaxis1.setTickUnit(new NumberTickUnit(10000d));
        xyplot.setRangeAxis(1,numberaxis1);  //设置Y轴
        xyplot.setDataset(1,createDataset6()); //添加数据集合
        xyplot.mapDatasetToRangeAxis(1,1); 
        xyplot.setBackgroundAlpha(0.0f);// 去掉柱状图的背景色
        xyplot.setOutlinePaint(null);// 去掉边框
        
        // y轴的设计
        NumberAxis x = (NumberAxis) xyplot.getDomainAxis();
        x.setAutoRange(true);// 自动设置数据轴数据范围
        // 自己设置横坐标的值
        x.setAutoTickUnitSelection(true);
        x.setTickUnit(new NumberTickUnit(1d));
        // 设置最大的显示值和最小的显示值
        x.setLowerBound(400);
        x.setUpperBound(415);
        // 数据轴的数据标签：只显示整数标签
        x.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        x.setAxisLineVisible(true);// X轴竖线是否显示
        x.setTickMarksVisible(false);// 标记线是否显示
        
        RectangleInsets offset = new RectangleInsets(0, 0, 0, 0);
        xyplot.setAxisOffset(offset);// 坐标轴到数据区的间距
        xyplot.setBackgroundAlpha(0.0f);// 去掉柱状图的背景色
        xyplot.setOutlinePaint(null);// 去掉边框
        
        XYLineAndShapeRenderer   xylineandshaperenderer=(XYLineAndShapeRenderer)xyplot.getRenderer(); 
        StandardXYToolTipGenerator.getTimeSeriesInstance(); 
        xylineandshaperenderer.setSeriesPaint(0, Color.BLUE);
        XYLineAndShapeRenderer   xylineandshaperenderer1   =   new   XYLineAndShapeRenderer(true,   false); 
        xylineandshaperenderer1.setSeriesPaint(0, Color.red); 
        xyplot.setRenderer(1,   xylineandshaperenderer1); 

        // ChartPanel chartPanel = new ChartPanel(jfreechart);
        // chartPanel.restoreAutoDomainBounds();//重置X轴

        ChartPanel chartPanel = new ChartPanel(jfreechart2, true);

        return chartPanel;
    }
    public JPanel getCPUJFreeChart3(){

        jfreechart3 = ChartFactory.createXYLineChart(
                null, "Gates", "Number  of  Thermal  Neutron", createDataset3(),
                PlotOrientation.VERTICAL, true, true, false);

        StandardChartTheme mChartTheme = new StandardChartTheme("CN");
        mChartTheme.setLargeFont(new Font("黑体", Font.BOLD, 20));
        mChartTheme.setExtraLargeFont(new Font("宋体", Font.PLAIN, 15));
        mChartTheme.setRegularFont(new Font("宋体", Font.PLAIN, 15));
        ChartFactory.setChartTheme(mChartTheme);

        jfreechart3.setBorderPaint(new Color(0,204,205));
        jfreechart3.setBorderVisible(true);

        XYPlot xyplot = (XYPlot) jfreechart3.getPlot();

        // Y轴
        NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
        numberaxis.setTickUnit(new NumberTickUnit(100d));
        // 只显示整数值
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        numberaxis.setLowerMargin(0); // 数据轴下（左）边距 ­
        numberaxis.setMinorTickMarksVisible(false);// 标记线是否显示
        numberaxis.setTickMarkInsideLength(0);// 外刻度线向内长度
        numberaxis.setTickMarkOutsideLength(0);
        numberaxis.setAxisLinePaint(Color.RED);
        numberaxis.setLabelPaint(Color.RED);
        numberaxis.setTickLabelPaint(Color.RED);
        //第二个Y轴
        NumberAxis   numberaxis1   =   new   NumberAxis("Number  of  Epithermal  Neutron  Particles"); 
        numberaxis1.setAutoRangeIncludesZero(false);
        numberaxis1.setAxisLinePaint(Color.BLUE);
        numberaxis1.setLabelPaint(Color.BLUE);
        numberaxis1.setTickLabelPaint(Color.BLUE);
        numberaxis1.setTickUnit(new NumberTickUnit(100d));
        xyplot.setRangeAxis(1,numberaxis1);  //设置Y轴
        xyplot.setDataset(1,createDataset4()); //添加数据集合
        xyplot.mapDatasetToRangeAxis(1,1); 
        xyplot.setBackgroundAlpha(0.0f);// 去掉柱状图的背景色
        xyplot.setOutlinePaint(null);// 去掉边框
        
        // X轴的设计
        NumberAxis x = (NumberAxis) xyplot.getDomainAxis();
        x.setAutoRange(true);// 自动设置数据轴数据范围
        // 自己设置横坐标的值
        x.setAutoTickUnitSelection(true);
        x.setTickUnit(new NumberTickUnit(20d));
        // 设置最大的显示值和最小的显示值
        x.setLowerBound(0);
        x.setUpperBound(130);
        // 数据轴的数据标签：只显示整数标签
        x.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        x.setAxisLineVisible(true);// X轴竖线是否显示
        x.setTickMarksVisible(false);// 标记线是否显示

        RectangleInsets offset = new RectangleInsets(0, 0, 0, 0);
        xyplot.setAxisOffset(offset);// 坐标轴到数据区的间距
        xyplot.setBackgroundAlpha(0.0f);// 去掉柱状图的背景色
        xyplot.setOutlinePaint(null);// 去掉边框
        
        XYLineAndShapeRenderer   xylineandshaperenderer=(XYLineAndShapeRenderer)xyplot.getRenderer(); 
        StandardXYToolTipGenerator.getTimeSeriesInstance(); 
        xylineandshaperenderer.setSeriesPaint(0, Color.red);
        XYLineAndShapeRenderer   xylineandshaperenderer1   =   new   XYLineAndShapeRenderer(true,   false); 
        xylineandshaperenderer1.setSeriesPaint(0, Color.blue); 
        xyplot.setRenderer(1,   xylineandshaperenderer1); 

        // ChartPanel chartPanel = new ChartPanel(jfreechart);
        // chartPanel.restoreAutoDomainBounds();//重置X轴

        ChartPanel chartPanel = new ChartPanel(jfreechart3, true);

        return chartPanel;
    }
    /**
     * 该方法是数据的设计
     *
     * @return
     */
    public static XYDataset createDataset1() {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(XYDATAS);
        return xyseriescollection;
    }
    public static XYDataset createDataset2() {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(XYDATAS2);
        return xyseriescollection;
    }
    public static XYDataset createDataset3() {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(XYDATAS3);
        return xyseriescollection;
    }
    public static XYDataset createDataset4() {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(XYDATAS4);
        return xyseriescollection;
    }
    public static XYDataset createDataset5() {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(XYDATAS5);
        return xyseriescollection;
    }
    public static XYDataset createDataset6() {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(XYDATAS5);
        return xyseriescollection;
    }
}

