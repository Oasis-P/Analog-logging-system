package Interface;

public class Test {

	public static void main(String[] args) 
	{// TODO �Զ����ɵķ������
		Data[] data=new Data[2];
		data[0]=new Data();
		data[1]=new Data();
		data[0].Value=8;
		data[1].Value=5;
		data[0].Depth=0;
		data[1].Depth=0;
		System.out.println(data[1].Value);
	}

}
