package Interface;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleInsets;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class JFreeZheXianTest2{
    public static XYSeries xyCPUseries = new XYSeries("CPU");
    public static int hundroud = 0;
    //鍒涘缓涓変釜JFreeChart鍒嗗埆鐢ㄤ簬涓嶅悓闇�姹傜殑缁樺埗
    public static JFreeChart jfreechart = null;
    public static JFreeChart jfreechart2 = null;
    public static JFreeChart jfreechart3 = null;
    public static JPanel jp1;
    public static javax.swing.JButton jp1_jb1;
    public static JPanel jp2;
    public static JPanel jp3;
    public static JPanel jp4;
    public static JTextField jf1;
    public static void main(String[] args) {
        JFreeZheXianTest jz = new JFreeZheXianTest();

        JFrame frame = new JFrame();
        frame.setBounds(50,200,1800,700);
        //鍒嗗埆鍒涘缓3涓狫anel锛岀敤浜�3涓狫FreeChart锛屽垎鍒缃叾澶у皬鍜屼綅缃紝骞舵坊鍔犲埌frame涓�
        //涓轰簡鐪嬭捣鏉ユ柟渚匡紝鍒嗗埆浣滀簡3涓嚱鏁般��
        JPanel myjp=jz.getCPUJFreeChart();
        myjp.setBounds(50,200,300,300);
        frame.getContentPane().add(myjp);


        JPanel myjp2=jz.getCPUJFreeChart2();
        myjp2.setBounds(400,200,300,300);
        frame.getContentPane().add(myjp2);

        JPanel myjp3=jz.getCPUJFreeChart3();
        myjp3.setBounds(800,200,300,300);
        frame.getContentPane().add(myjp3);

        //鍒涘缓涓変釜JPanel锛岀敤浜庤杞介渶瑕佺殑鍏朵粬鎺т欢缁勶紝骞惰缃ソ浣嶇疆锛屽ぇ灏忥紝娣诲姞鍒癴rame涓��
        jp1 = new JPanel();
        javax.swing.JButton  send= new javax.swing.JButton ("start draw1");
        send.setBounds(0, 120, 100, 30);
        send.setForeground(Color.BLACK);
        jp1.add(send);
        jf1 = new JTextField("111111");
        jf1.setBounds(150, 120, 150, 30);
        jp1.add(jf1);
        jf1.setBounds(150, 120, 150, 30);
        jp1.setBounds(100, 600, 150, 50);
        frame.getContentPane().add(jp1);

        jp2= new JPanel();
        javax.swing.JButton send2=new javax.swing.JButton("start draw2");
        send2.setBounds(150, 120, 100, 30);
        send2.setForeground(Color.BLACK);
        jp2.add(send2);
        jp2.setBounds(300, 600, 150, 50);
        frame.getContentPane().add(jp2);
  //鍑犱釜panel鐨勪綅缃湁鍐茬獊锛屾墍浠ョ涓変釜鎸夐挳浣嶇疆鏄剧ず涓嶅锛岃嚜宸辫皟鏁�
        jp3= new JPanel();
        javax.swing.JButton send3=new javax.swing.JButton("start draw3");
        send3.setBounds(150, 120, 100, 30);
        send3.setForeground(Color.BLACK);
        jp3.add(send3);
        jp3.setBounds(450, 600, 150, 50);
        frame.getContentPane().add(jp3);

        jp4= new JPanel();
        javax.swing.JButton send4=new javax.swing.JButton("start draw4");
        send4.setBounds(150, 120, 100, 30);
        send4.setForeground(Color.BLACK);
        jp4.add(send4);
        jp4.setBounds(600, 600, 150, 50);
       frame.getContentPane().add(jp4);
       jp4.setVisible(false);
//閽堝涓変釜panel涓婄殑涓変釜涓嶅悓鐨勬寜閽坊鍔犱睛鍚櫒锛岀劧鍚庡垎鍒皟鐢ㄤ笉鍚岀殑dynamicRun鍑芥暟浠ョず鍖哄垎锛屼篃鍙互鍦ㄥ嚱鏁颁腑澧炲姞鍙傛暟锛屾牴鎹疄闄呴渶瑕侀�夋嫨鎬庝箞鍋氥��
        send.addActionListener(new ActionListener() {
       @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Runnable r = ()->{
                        jf1.setText("鏂板弬鏁�");
                        dynamicRun();
                    };
                    //閲嶅惎涓�涓嚎绋嬪幓鍔ㄦ�佺粯鍥�
                    new Thread(r).start();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });

        send2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Runnable r = ()->{
                        dynamicRun2();
                    };
                    //閲嶅惎涓�涓嚎绋嬪幓鍔ㄦ�佺粯鍥�
                    new Thread(r).start();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });


        send3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Runnable r = ()->{
                        dynamicRun3();
                    };
                    //閲嶅惎涓�涓嚎绋嬪幓鍔ㄦ�佺粯鍥�
                    new Thread(r).start();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });

        frame.setVisible(true);
        frame.setLocationRelativeTo(null); // 绐楀彛灞呬簬灞忓箷姝ｄ腑澶�
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
//        dynamicRun();

    }

    /**
     * 闅忔満鐢熸垚鐨勬暟鎹�
     */
    public static void dynamicRun() {
        int i = 0;
        while (true) {

            double factor = Math.random()*100;

            hundroud = (int)factor;
            jfreechart.setTitle("1111111111");
            jfreechart.getTitle().setFont(new Font("寰蒋闆呴粦", 0, 16));//璁剧疆鏍囬瀛椾綋

            xyCPUseries.add(i, factor);

            try {
                Thread.currentThread();
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            i++;
            if (i == 60){
                i=0;
                xyCPUseries.delete(0, 59);
                continue;
            }
        }
    }

    public static void dynamicRun2() {
        int i = 0;
        while (true) {

            double factor = Math.random()*100;

            hundroud = (int)factor;
            jfreechart2.setTitle("2222222222222222");
            jfreechart2.getTitle().setFont(new Font("寰蒋闆呴粦", 0, 16));//璁剧疆鏍囬瀛椾綋

            xyCPUseries.add(i, factor);

            try {
                Thread.currentThread();
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            i++;
            if (i == 60){
                i=0;
                xyCPUseries.delete(0, 59);
                continue;
            }
        }
    }

    public static void dynamicRun3() {
        int i = 0;
        while (true) {

            double factor = Math.random()*100;

            hundroud = (int)factor;
            jfreechart3.setTitle("33333333333");
            jfreechart3.getTitle().setFont(new Font("寰蒋闆呴粦", 0, 16));//璁剧疆鏍囬瀛椾綋

            xyCPUseries.add(i, factor);

            try {
                Thread.currentThread();
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            i++;
            if (i == 60){
                i=0;
                xyCPUseries.delete(0, 59);
                continue;
            }
        }
    }

    public JPanel getCPUJFreeChart(){

        jfreechart = ChartFactory.createXYLineChart(
                null, null, null, createDataset1(),
                PlotOrientation.VERTICAL, false, true, false);

        StandardChartTheme mChartTheme = new StandardChartTheme("CN");
        mChartTheme.setLargeFont(new Font("榛戜綋", Font.BOLD, 20));
        mChartTheme.setExtraLargeFont(new Font("瀹嬩綋", Font.PLAIN, 15));
        mChartTheme.setRegularFont(new Font("瀹嬩綋", Font.PLAIN, 15));
        //ChartFactory.setChartTheme(mChartTheme);

        jfreechart.setBorderPaint(new Color(0,204,205));
        jfreechart.setBorderVisible(true);

        XYPlot xyplot = (XYPlot) jfreechart.getPlot();

        // Y杞�
        NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
        numberaxis.setLowerBound(0);
        numberaxis.setUpperBound(100);
        numberaxis.setTickUnit(new NumberTickUnit(100d));
        // 鍙樉绀烘暣鏁板��
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        // numberaxis.setAutoRangeIncludesZero(true);
        numberaxis.setLowerMargin(0); // 鏁版嵁杞翠笅锛堝乏锛夎竟璺� 颅
        //numberaxis.setMinorTickMarksVisible(false);// 鏍囪绾挎槸鍚︽樉绀�
        numberaxis.setTickMarkInsideLength(0);// 澶栧埢搴︾嚎鍚戝唴闀垮害
        numberaxis.setTickMarkOutsideLength(0);

        // X杞寸殑璁捐
        NumberAxis x = (NumberAxis) xyplot.getDomainAxis();
        x.setAutoRange(true);// 鑷姩璁剧疆鏁版嵁杞存暟鎹寖鍥�
        // 鑷繁璁剧疆妯潗鏍囩殑鍊�
        x.setAutoTickUnitSelection(false);
        x.setTickUnit(new NumberTickUnit(60d));
        // 璁剧疆鏈�澶х殑鏄剧ず鍊煎拰鏈�灏忕殑鏄剧ず鍊�
        x.setLowerBound(0);
        x.setUpperBound(60);
        // 鏁版嵁杞寸殑鏁版嵁鏍囩锛氬彧鏄剧ず鏁存暟鏍囩
        x.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        x.setAxisLineVisible(true);// X杞寸珫绾挎槸鍚︽樉绀�
        x.setTickMarksVisible(false);// 鏍囪绾挎槸鍚︽樉绀�

        RectangleInsets offset = new RectangleInsets(0, 0, 0, 0);
        //xyplot.setAxisOffset(offset);// 鍧愭爣杞村埌鏁版嵁鍖虹殑闂磋窛
        xyplot.setBackgroundAlpha(0.0f);// 鍘绘帀鏌辩姸鍥剧殑鑳屾櫙鑹�
        xyplot.setOutlinePaint(null);// 鍘绘帀杈规

        // ChartPanel chartPanel = new ChartPanel(jfreechart);
        // chartPanel.restoreAutoDomainBounds();//閲嶇疆X杞�

        ChartPanel chartPanel = new ChartPanel(jfreechart, true);

        return chartPanel;
    }

    public JPanel getCPUJFreeChart2(){

        jfreechart2 = ChartFactory.createXYLineChart(
                null, null, null, createDataset1(),
                PlotOrientation.VERTICAL, false, true, false);

        StandardChartTheme mChartTheme = new StandardChartTheme("CN");
        mChartTheme.setLargeFont(new Font("榛戜綋", Font.BOLD, 20));
        mChartTheme.setExtraLargeFont(new Font("瀹嬩綋", Font.PLAIN, 15));
        mChartTheme.setRegularFont(new Font("瀹嬩綋", Font.PLAIN, 15));
        //ChartFactory.setChartTheme(mChartTheme);

        jfreechart2.setBorderPaint(new Color(0,204,205));
        jfreechart2.setBorderVisible(true);

        XYPlot xyplot = (XYPlot) jfreechart2.getPlot();

        // Y杞�
        NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
        numberaxis.setLowerBound(0);
        numberaxis.setUpperBound(100);
        numberaxis.setTickUnit(new NumberTickUnit(100d));
        // 鍙樉绀烘暣鏁板��
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        // numberaxis.setAutoRangeIncludesZero(true);
        numberaxis.setLowerMargin(0); // 鏁版嵁杞翠笅锛堝乏锛夎竟璺� 颅
        //numberaxis.setMinorTickMarksVisible(false);// 鏍囪绾挎槸鍚︽樉绀�
        numberaxis.setTickMarkInsideLength(0);// 澶栧埢搴︾嚎鍚戝唴闀垮害
        numberaxis.setTickMarkOutsideLength(0);

        // X杞寸殑璁捐
        NumberAxis x = (NumberAxis) xyplot.getDomainAxis();
        x.setAutoRange(true);// 鑷姩璁剧疆鏁版嵁杞存暟鎹寖鍥�
        // 鑷繁璁剧疆妯潗鏍囩殑鍊�
        x.setAutoTickUnitSelection(false);
        x.setTickUnit(new NumberTickUnit(60d));
        // 璁剧疆鏈�澶х殑鏄剧ず鍊煎拰鏈�灏忕殑鏄剧ず鍊�
        x.setLowerBound(0);
        x.setUpperBound(60);
        // 鏁版嵁杞寸殑鏁版嵁鏍囩锛氬彧鏄剧ず鏁存暟鏍囩
        x.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        x.setAxisLineVisible(true);// X杞寸珫绾挎槸鍚︽樉绀�
        x.setTickMarksVisible(false);// 鏍囪绾挎槸鍚︽樉绀�

        RectangleInsets offset = new RectangleInsets(0, 0, 0, 0);
        //xyplot.setAxisOffset(offset);// 鍧愭爣杞村埌鏁版嵁鍖虹殑闂磋窛
        xyplot.setBackgroundAlpha(0.0f);// 鍘绘帀鏌辩姸鍥剧殑鑳屾櫙鑹�
        xyplot.setOutlinePaint(null);// 鍘绘帀杈规

        // ChartPanel chartPanel = new ChartPanel(jfreechart);
        // chartPanel.restoreAutoDomainBounds();//閲嶇疆X杞�

        ChartPanel chartPanel = new ChartPanel(jfreechart2, true);

        return chartPanel;
    }
    public JPanel getCPUJFreeChart3(){

        jfreechart3 = ChartFactory.createXYLineChart(
                null, null, null, createDataset1(),
                PlotOrientation.VERTICAL, false, true, false);

        StandardChartTheme mChartTheme = new StandardChartTheme("CN");
        mChartTheme.setLargeFont(new Font("榛戜綋", Font.BOLD, 20));
        mChartTheme.setExtraLargeFont(new Font("瀹嬩綋", Font.PLAIN, 15));
        mChartTheme.setRegularFont(new Font("瀹嬩綋", Font.PLAIN, 15));
        //ChartFactory.setChartTheme(mChartTheme);

        jfreechart3.setBorderPaint(new Color(0,204,205));
        jfreechart3.setBorderVisible(true);

        XYPlot xyplot = (XYPlot) jfreechart3.getPlot();

        // Y杞�
        NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
        numberaxis.setLowerBound(0);
        numberaxis.setUpperBound(100);
        numberaxis.setTickUnit(new NumberTickUnit(100d));
        // 鍙樉绀烘暣鏁板��
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        // numberaxis.setAutoRangeIncludesZero(true);
        numberaxis.setLowerMargin(0); // 鏁版嵁杞翠笅锛堝乏锛夎竟璺� 颅
        //numberaxis.setMinorTickMarksVisible(false);// 鏍囪绾挎槸鍚︽樉绀�
        numberaxis.setTickMarkInsideLength(0);// 澶栧埢搴︾嚎鍚戝唴闀垮害
        numberaxis.setTickMarkOutsideLength(0);

        // X杞寸殑璁捐
        NumberAxis x = (NumberAxis) xyplot.getDomainAxis();
        x.setAutoRange(true);// 鑷姩璁剧疆鏁版嵁杞存暟鎹寖鍥�
        // 鑷繁璁剧疆妯潗鏍囩殑鍊�
        x.setAutoTickUnitSelection(false);
        x.setTickUnit(new NumberTickUnit(60d));
        // 璁剧疆鏈�澶х殑鏄剧ず鍊煎拰鏈�灏忕殑鏄剧ず鍊�
        x.setLowerBound(0);
        x.setUpperBound(60);
        // 鏁版嵁杞寸殑鏁版嵁鏍囩锛氬彧鏄剧ず鏁存暟鏍囩
        x.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        x.setAxisLineVisible(true);// X杞寸珫绾挎槸鍚︽樉绀�
        x.setTickMarksVisible(false);// 鏍囪绾挎槸鍚︽樉绀�

        RectangleInsets offset = new RectangleInsets(0, 0, 0, 0);
        //xyplot.setAxisOffset(offset);// 鍧愭爣杞村埌鏁版嵁鍖虹殑闂磋窛
        xyplot.setBackgroundAlpha(0.0f);// 鍘绘帀鏌辩姸鍥剧殑鑳屾櫙鑹�
        xyplot.setOutlinePaint(null);// 鍘绘帀杈规

        // ChartPanel chartPanel = new ChartPanel(jfreechart);
        // chartPanel.restoreAutoDomainBounds();//閲嶇疆X杞�

        ChartPanel chartPanel = new ChartPanel(jfreechart3, true);

        return chartPanel;
    }
    /**
     * 璇ユ柟娉曟槸鏁版嵁鐨勮璁�
     *
     * @return
     */
    public static XYDataset createDataset1() {
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(xyCPUseries);
        return xyseriescollection;
    }

}

