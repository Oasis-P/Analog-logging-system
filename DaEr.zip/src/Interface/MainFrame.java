package Interface;
 
import javax.swing.*;
 public class MainFrame extends JFrame 
 {
	 private JButton button;
	 private JTextField fieldText;
	 private JLabel jLabel;
	 private JLabel jTextField;
	 private JLabel labelText;
	 
	 public MainFrame() 
	 {	//->��->initComponents��->
	 initComponents();
	 }
 // <editor-fold defaultstate="collapsed" desc="Generated Code"> 
	 private void initComponents() 
	 {	//->��->��        //��ʼ����� 	
		 jLabel = new JLabel();
		 labelText = new JLabel();
		 jTextField = new JLabel();
		 fieldText = new JTextField();
		 button = new JButton();
		 setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		 jLabel.setText("JLabel:");
		 labelText.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		 jTextField.setText("JTextField: ");
		 button.setText("click");
		 
		 button.addActionListener(new java.awt.event.ActionListener() 
		 {
			 public void actionPerformed(java.awt.event.ActionEvent evt) 
			 {
				 buttonActionPerformed(evt);//->��->��->�ۼ�����
			 }
		 });
		 //�������
		 GroupLayout layout = new GroupLayout(getContentPane());
		 getContentPane().setLayout(layout);
		 layout.setHorizontalGroup(
			 layout.createParallelGroup(GroupLayout.Alignment.LEADING)
			 .addGroup(layout.createSequentialGroup()
				 .addGap(10, 10, 10)
				 .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
					 .addComponent(button)
					 .addGroup(layout.createSequentialGroup()
						 .addComponent(jLabel)
						 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						 .addComponent(labelText, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
					 )
					 .addGroup(layout.createSequentialGroup()
						 .addComponent(jTextField)
						 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						 .addComponent(fieldText, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
				 )
				 )
				 .addContainerGap(10, Short.MAX_VALUE)
			 )
		 );
		 layout.setVerticalGroup(
			 layout.createParallelGroup(GroupLayout.Alignment.LEADING)
			 .addGroup(layout.createSequentialGroup()
				 .addGap(10, 10, 10)
				 .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
					 .addComponent(jLabel)
					 .addComponent(labelText, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
				 )
				 .addGap(10, 10, 10)//�����м�϶
				 .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
					 .addComponent(jTextField)
					 .addComponent(fieldText,GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
				 )
				 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
				 .addComponent(button)
				 .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
			 )
		 );
		 
		 pack();
	 }// </editor-fold>
	 		//->��->��->�ۼ�����
	 private void buttonActionPerformed(java.awt.event.ActionEvent evt)
	 { 
		 new Thread(new Runnable() {
	         @Override
	         public void run() {
	             changeText("Button clicked");
	             try {
	                 Thread.sleep(1000);
	             } catch (InterruptedException ex) {
	                 ex.printStackTrace();
	             }
	             changeText("Start to change text...");
	             try {
	                 Thread.sleep(1000);
	             } catch (InterruptedException ex) {
	                 ex.printStackTrace();
	             }
	             for (int i = 0; i < 10; i++) {
	                 changeText((i+1)+"");
	                 try {
	                     Thread.sleep(1000);
	                 } catch (InterruptedException ex) {
	                     ex.printStackTrace();
	                 }
	             }
	             changeText("action end");
	         }
	     }).start();
	 }
	
	 private void changeText(String text) {
	 labelText.setText(text);
	 fieldText.setText(text);
	 }
	
	 public static void main(String args[]) 
	 {
		 java.awt.EventQueue.invokeLater(new Runnable()
		 {
			 public void run() //��run
			 {							
				 new MainFrame().setVisible(true);
			 }
		 });
	}
}
