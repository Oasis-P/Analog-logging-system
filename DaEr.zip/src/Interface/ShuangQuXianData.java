package Interface;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;

import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import test.GetFilePath;

public class ShuangQuXianData 
{
	public   static   Data[]   createDataset2() throws Exception
    { 
            //XYSeries   xyseries   =   new   XYSeries( "��"); 
            double sum=0.0;int i=0;
            String[] s=new String[1030];
            ArrayList<File> FileList=GetFilePath.getFiles("D:\\0218\\���\\��Ȼ��");
            Data[] data = new Data[FileList.size()];//���ݶ���
            System.out.println(FileList.size());
            try
            {
            	for(i=0;i<FileList.size();i++)
        		{
        			String curpath = FileList.get(i).getPath();//��ȡ�ļ�·��
        			FileReader  fr=new FileReader(curpath); 
        			BufferedReader bfr=new BufferedReader(fr);
                    int m=0;
                    String str;
                    String[] st;
                    while((str=bfr.readLine())!=null) //��ȡ�ļ�����
                    {
                        st=str.split(",");
                        for(String j:st) 
                        {
                            s[m]=j;
                            m++;
                        }
                    } 
                    bfr.close();
                    fr.close();
                    for(int n=6;n<m;n++) //���
                    {sum= Double.valueOf(s[n].toString())+sum;}//ת��Ϊdouble���͵�����//������Ϊ���ܷ����쳣�Ĵ���η�������
                    data[i]=new Data();//��ʼ���������ڴ�
                    data[i].Value=sum;
                    data[i].Depth=Double.valueOf(s[0].toString());
                    //System.out.println("�ã�"+sum+"���"+data[i].Depth);
                    sum=0; //sum��ʼ��  
                }
                /*for(int j=0;j<FileList.size();j++) //����������������
                {
                	xyseries.add(data[j].Depth, data[j].Value);//add(double x, double y)	
                }
            	if(max<data[0].Depth)
                	max=data[0].Depth;
                if(min>data[i-1].Depth)
                	min=data[i-1].Depth;*/
            } 
            catch (FileNotFoundException e) 
            {
                e.printStackTrace();
            }
            return   data; 
    }
    //(E/T���ݼ���)
	public   static   Data[]   createDataset1() throws Exception
    { 
            XYSeries   xyseries   =   new   XYSeries( "��������/������(E/T)       "); 
            double sumE=0,sumT=0;int i=0;
            ArrayList<File> FileListE=GetFilePath.getFiles("D:\\0218\\���\\��������");//���������ļ�
			ArrayList<File> FileListT=GetFilePath.getFiles("D:\\0218\\���\\������");//�������ļ�
            String[] sE=new String[130];
            String[] sT=new String[130];
            Data[] data = new Data[FileListE.size()];//���
            try 
            {	
            	for(;i<FileListE.size();i++)
        		{	
        			String curpathE = FileListE.get(i).getPath();//��ȡ���������ļ�·��
        			FileReader  frE=new FileReader(curpathE); 
        			BufferedReader bfrE=new BufferedReader(frE);
        			
        			String curpathT = FileListT.get(i).getPath();//��ȡ�������ļ�·��
        			FileReader  frT=new FileReader(curpathT); 
        			BufferedReader bfrT=new BufferedReader(frT);
        			
                    int m=0;
                    String str;
                    String[] stE;
                    while((str=bfrE.readLine())!=null) //��ȡ�ļ�����
                    {
                        stE=str.split(",");
                        for(String j:stE) 
                        {
                            sE[m]=j;
                            m++;
                        }
                    } 
                    m=0;
                    String[] stT;
                    while((str=bfrT.readLine())!=null) //��ȡ�ļ�����
                    {
                        stT=str.split(",");
                        for(String j:stT) 
                        {
                            sT[m]=j;
                            m++;
                        }
                    }
                    bfrT.close();
                    frT.close();
                    bfrE.close();
                    frE.close();
                    for(int n=2;n<m;n++) //���
                    {
                    	sumE= Double.valueOf(sE[n].toString())+sumE;//ת��Ϊdouble���͵�����
                    	sumT= Double.valueOf(sT[n].toString())+sumT;
                    }
                    data[i]=new Data();//��ʼ���������ڴ�
                    data[i].Value=sumE/sumT;
                    data[i].Depth=Double.valueOf(sE[0].toString());
                    System.out.println("�������ӣ�"+sumE+"�����ӣ�"+sumT+"��ȣ�"+"��������/������:"+data[i].Value+data[i].Depth);
                    sumE=0;
                    sumT=0;
                }
                for(int j=0;j<130;j++) //����������������
                {
                	xyseries.add(data[i].Depth, data[i].Value);//add(double x, double y)
                }
                /*max=depth[0];
                min=depth[i-1];*/
                //System.out.println(depth[0]);
            } 
			catch (FileNotFoundException e) 
            {
                e.printStackTrace();
            }
            return   data;
    }
}
