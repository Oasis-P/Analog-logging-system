package Interface;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.*;

import org.jfree.chart.ChartPanel;

import test.read_t;
public class Interface 
{
	public static JFrame frame=new JFrame("abc");
	static JTextField text =new JTextField();
	static JButton button1 = new JButton("��ʼģ��");
//	static ChartPanel pan=new ChartPanel(null);
	public static void main(String   args[]) throws Exception 
	{	// TODO �Զ����ɵķ������
		
		final Interface inter = new Interface();
		frame.setSize(1800, 850);
		frame.setLayout(null);
		text.setBounds(20, 460, 400, 40);
		button1.setBounds(30, 510, 200, 40);
		//pan.setBounds(0, 0, 400, 400);
		frame.add(text);
	    frame.add(button1);
		/*JPanel panel1=new JPanel();
		panel1.setBounds(0, 0, 1800, 450);
		panel1.setLayout(null);*/
	    
		//JTextField field1=new JTextField();
		//JButton button1=new JButton();
		frame.setLocationRelativeTo(null);//����λ��
		frame.setVisible(true);
		frame.setDefaultCloseOperation(3);
		//read_t.mai(frame,text,button1);
		//field1.setBounds(600, 0, 600, 450);
		//button1.setBounds(1200, 0, 600, 450);
		///panel1.add(field1);
		
		/*JPanel panel2=new JPanel();
		panel2.setBounds(0, 400, 1800, 200);
		panel2.setLayout(new GridLayout(1,3));
		JLabel l2=new JLabel("4534");
		JTextField field2=new JTextField();
		JButton button2=new JButton();
		panel2.add(l2);
		panel2.add(field2);
		panel2.add(button2);*/
		
		//frame.add(panel1);
		//frame.add(panel2);
		
		button1.addActionListener(new ActionListener() 
		{@Override
			public void actionPerformed(ActionEvent arg0) 
			{// TODO �Զ����ɵķ������
				try
				{
					read_t.mai(inter);
				} 
				catch (Exception e)
				{// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
			
		}
				); 
	
	}
}
