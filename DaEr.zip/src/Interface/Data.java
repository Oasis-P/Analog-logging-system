package Interface;

public class Data 
{
	public double Value=0;
	public double Depth=0;
	
}
